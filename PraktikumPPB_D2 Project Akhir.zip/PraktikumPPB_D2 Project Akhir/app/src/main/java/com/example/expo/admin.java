package com.example.expo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class admin extends AppCompatActivity {
    Button login;
    EditText edit_user, edit_pass;
    String user_admin = "admin", pass_admin = "12345";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        login = findViewById(R.id.login);
        edit_user = findViewById(R.id.edit_user);
        edit_pass = findViewById(R.id.edit_pass);
    }

    public void beradm(View view) {
        String username = edit_user.getText().toString();
        String password = edit_pass.getText().toString();
        if (user_admin.equals(username) && pass_admin.equals(password)) {
            Intent pin = new Intent(admin.this,beranda_admin.class);
            startActivity(pin);
        }
        else if(username.isEmpty()){
            Toast.makeText(this, "Isikan Username", Toast.LENGTH_SHORT).show();
        }
        else if(password.isEmpty()){
            Toast.makeText(this, "Isikan Password", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Nama dan Password Salah", Toast.LENGTH_SHORT).show();
        }
    }
}
