package com.example.expo;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LihatData extends AppCompatActivity {
    // inisialisasi
    protected Cursor cursor;
    DataHelper dbHelper;
    Button kembali3;
    private TextView nim,nama,prodi,fakultas,nohp,ttl,alamat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lihat_data);

        nim = (TextView)findViewById(R.id.editnim1);
        nama = (TextView)findViewById(R.id.editnama1);
        prodi = (TextView)findViewById(R.id.editprodi1);
        fakultas = (TextView)findViewById(R.id.editfak1);
        nohp = (TextView)findViewById(R.id.editno1);
        ttl = (TextView)findViewById(R.id.editttl1);
        alamat = (TextView)findViewById(R.id.editalamat1);

        dbHelper = new DataHelper(this);//variabel=new class()
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM biodata WHERE nim = '" +
                getIntent().getStringExtra("nim") + "'",null);
        cursor.moveToFirst();
        if (cursor.getCount()>0)
        {
            cursor.moveToPosition(0);
            nim.setText(cursor.getString(0).toString());
            nama.setText(cursor.getString(1).toString());
            prodi.setText(cursor.getString(2).toString());
            fakultas.setText(cursor.getString(3).toString());
            nohp.setText(cursor.getString(4).toString());
            ttl.setText(cursor.getString(5).toString());
            alamat.setText(cursor.getString(6).toString());
        }

        kembali3 = (Button) findViewById(R.id.btn_kembali);

    }

    public void back(View view) {
        Intent pin = new Intent(this,beranda_admin.class);
        startActivity(pin);
    }
}