package com.example.expo;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class daftar extends AppCompatActivity {

    private EditText nim,nama,prodi,fakultas,nohp,ttl,alamat;
    DataHelper dbcenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);

        dbcenter = new DataHelper(this);
        nim = (EditText)findViewById(R.id.editnim);
        nama = (EditText)findViewById(R.id.editnama);
        prodi = (EditText)findViewById(R.id.editprodi);
        fakultas = (EditText)findViewById(R.id.editfak);
        nohp = (EditText)findViewById(R.id.editno);
        ttl = (EditText)findViewById(R.id.editttl);
        alamat = (EditText)findViewById(R.id.editalamat);
    }

    public void sign(View view) {
        SQLiteDatabase db = dbcenter.getWritableDatabase();
        db.execSQL("insert into biodata values('" +
                nim.getText().toString()+"','"+
                nama.getText().toString()+"','"+
                prodi.getText().toString()+"','"+
                fakultas.getText().toString()+"','"+
                nohp.getText().toString()+"','"+
                ttl.getText().toString()+"','"+
                alamat.getText().toString()+ "')");
        Toast.makeText(getApplicationContext(), "Berhasil menyimpan data!", Toast.LENGTH_LONG).show();
        beranda_admin.beradm.RefreshList();
        finish();
        Intent pin = new Intent(this,MainActivity.class);
        startActivity(pin);
    }
}
