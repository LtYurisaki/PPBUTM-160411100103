package com.example.expo;

import android.content.Context;
        import android.content.Intent;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

public class UbahData extends AppCompatActivity {
    protected Cursor cursor;
    DataHelper dbHelper;
    Button ubah, kembali2;
    private EditText nim,nama,prodi,fakultas,nohp,ttl,alamat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubah_data);
        dbHelper = new DataHelper(this);

        nim = (EditText)findViewById(R.id.editnim2);
        nama = (EditText)findViewById(R.id.editnama2);
        prodi = (EditText)findViewById(R.id.editprodi2);
        fakultas = (EditText)findViewById(R.id.editfak2);
        nohp = (EditText)findViewById(R.id.editno2);
        ttl = (EditText)findViewById(R.id.editttl2);
        alamat = (EditText)findViewById(R.id.editalamat2);
        ubah = (Button) findViewById(R.id.btn_simpan);
        kembali2 = (Button) findViewById(R.id.btn_kembali);

        nim.setEnabled(false);

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM biodata WHERE nim = '" +
                getIntent().getStringExtra("nim") + "'",null);
        cursor.moveToFirst();
        if (cursor.getCount()>0)
        {
            cursor.moveToPosition(0);
            nim.setText(cursor.getString(0).toString());
            nama.setText(cursor.getString(1).toString());
            prodi.setText(cursor.getString(2).toString());
            fakultas.setText(cursor.getString(3).toString());
            nohp.setText(cursor.getString(4).toString());
            ttl.setText(cursor.getString(5).toString());
            alamat.setText(cursor.getString(6).toString());
        }
    }

    public void ubah(View view) {
        SQLiteDatabase dba = dbHelper.getWritableDatabase();
        dba.execSQL("update biodata set nama='" + nama.getText().toString() + "', prodi='"+prodi.getText().toString()+"',fakultas='"+fakultas.getText().toString()+"',nohp='"+nohp.getText().toString()+"',tetala='"+ttl.getText().toString()+"',alamat='" + alamat.getText().toString() + "' where nim='" + nim.getText().toString() + "'");
        Toast.makeText(getApplicationContext(), "Berhasil memperbarui data!", Toast.LENGTH_LONG).show();
        beranda_admin.beradm.RefreshList();
        finish();
        Intent pin = new Intent(this,beranda_admin.class);
        startActivity(pin);
    }

    public void bacck(View view) {
        Intent pin = new Intent(this,beranda_admin.class);
        startActivity(pin);
    }
}
