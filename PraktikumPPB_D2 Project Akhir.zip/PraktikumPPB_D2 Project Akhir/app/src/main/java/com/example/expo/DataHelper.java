package com.example.expo;

import android.content.Context;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;
        import android.util.Log;
        import android.widget.Toast;

public class DataHelper extends SQLiteOpenHelper {

    // nama database
    private static final String DATABASE_NAME = "pendaftara.db";

    private static final int DATABASE_VERSION = 1;

    public DataHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        // TODO Auto-generated constructor stub
    }

    // waktu pertama kali saat install apk akan membuat data base
    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL("create table biodata(nim integer primary key , nama text not null , prodi text not null , fakultas text not null , nohp integer not null , tetala text not null , alamat text not null)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
