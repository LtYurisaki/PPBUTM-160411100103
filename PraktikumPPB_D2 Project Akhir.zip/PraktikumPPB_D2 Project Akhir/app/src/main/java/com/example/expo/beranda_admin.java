package com.example.expo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class beranda_admin extends AppCompatActivity {

    String[] data;
    ListView list_biodata;
    Menu option;
    protected Cursor cursor;
    DataHelper dbcenter;
    public static beranda_admin beradm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda_admin);
        beradm = this;
        dbcenter = new DataHelper(this);
        RefreshList();
    }

    public void RefreshList(){
        // menampilkan data biodata
        SQLiteDatabase db = dbcenter.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM biodata",null);
        data = new String[cursor.getCount()];
        cursor.moveToFirst();
        for (int cc=0; cc < cursor.getCount(); cc++){
            cursor.moveToPosition(cc);
            data[cc] = cursor.getString(0).toString();
        }

        // menu konteks untuk option
        list_biodata = (ListView)findViewById(R.id.listView);
        list_biodata.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, data));
        list_biodata.setSelected(true);
        list_biodata.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            public void onItemClick(AdapterView arg0, View arg1, int arg2, long arg3) {
                final String selection = data[arg2]; //.getItemAtPosition(arg2).toString();
                final CharSequence[] dialogitem = {"Lihat Data", "Edit Data", "Hapus Data"};
                AlertDialog.Builder builder = new AlertDialog.Builder(beranda_admin.this);
                builder.setTitle("Pilih Menu:");
                builder.setItems(dialogitem, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        switch(item){
                            case 0 :
                                Intent i = new Intent(getApplicationContext(), LihatData.class);
                                i.putExtra("nim", selection);
                                startActivity(i);
                                break;
                            case 1 :
                                Intent in = new Intent(getApplicationContext(), UbahData.class);
                                in.putExtra("nim", selection);
                                startActivity(in);
                                break;

                            case 2 :
                                SQLiteDatabase db = dbcenter.getWritableDatabase();
                                db.execSQL("delete from biodata where nim = '"+selection+"'");
                                Toast.makeText(getApplicationContext(),selection+" Telah Di Hapus",Toast.LENGTH_LONG).show();
                                RefreshList();
                                break;
                        }
                    }
                });
                builder.create().show();
            }});
        ((ArrayAdapter)list_biodata.getAdapter()).notifyDataSetInvalidated();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==R.id.about){
            Intent about = new Intent(this,about.class);
            startActivity(about);

        } else if (item.getItemId() == R.id.out) {
            Intent outt = new Intent(this,MainActivity.class);
            startActivity(outt);
        }

        return true;
    }
}
